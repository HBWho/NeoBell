import logging

# Import the service classes for type hinting
#from tts_service import TTSService
#from stt_service import STTService

logger = logging.getLogger(__name__)

# Keyword Definitions for Interpretation
AFFIRMATIVE_WORDS = {'yes', 'yeah', 'yep', 'sure', 'correct', 'right', 'affirmative'}
NEGATIVE_WORDS = {'no', 'nope', 'negative', 'wrong', 'incorrect'}

class InteractionManager:
    """
    A centralized manager for handling common user interaction flows,
    like asking questions and interpreting responses. This class requires
    TTS and STT services to be injected upon initialization.
    """
    def __init__(self, tts_service , stt_service ):
        """
        Initializes the InteractionManager with necessary services.

        Args:
            tts_service (TTSService): An initialized instance of the TTS service.
            stt_service (STTService): An initialized instance of the STT service.
        """
        self.tts = tts_service
        self.stt = stt_service
        logger.info("InteractionManager initialized.")

    def ask_yes_no(
        self,
        question: str,
        override: bool = True,
        listen_duration_seconds: int = 5
    ) -> bool:
        """
        Asks a user a yes/no question and interprets the answer.
        This method is synchronous.

        Args:
            question (str): The question to ask the user.
            listen_duration_seconds (int): How long to listen for an answer.

        Returns:
            bool: True for affirmative, False for negative.
        """
        if not question:
            logger.error("ask_yes_no called with an empty question.")
            return False

        max_attempts = 3

        # 1. Ask the question using the injected TTS service.
        self.tts.speak(question, override)

        for attempt in range(max_attempts):
            # 2. Wait for the user to respond.
            logger.info(f"Waiting for user response for {listen_duration_seconds} seconds...")
            transcribed_text = self.stt.transcribe_audio()
            if not transcribed_text:
                logger.warning("No text was transcribed from the user's response.")
                self.tts.speak("I'm sorry, I didn't quite catch that. Could you please clarify?")
                continue

            # 3. Process and interpret the response.
            processed_response = transcribed_text.lower().strip()
            logger.info(f"User response transcribed as: '{processed_response}'")
            
            response_words = set(processed_response.split())

            is_affirmative = not response_words.isdisjoint(AFFIRMATIVE_WORDS)
            is_negative = not response_words.isdisjoint(NEGATIVE_WORDS)

            if is_affirmative and is_negative:
                logger.warning(f"Conflicting responses detected: '{processed_response}'")
                self.tts.speak("I'm sorry, I didn't quite catch that. Could you please clarify?")
                continue

            if is_affirmative:
                logger.info("Affirmative answer detected.")
                return True

            if is_negative:
                logger.info("Negative answer detected.")
                return False
            
        logger.warning(f"Could not determine intent from response: '{processed_response}'")
        return False

