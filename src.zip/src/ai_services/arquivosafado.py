import cv2
print(cv2.ocl.haveOpenCL())