import time
import os
import logging
import cv2 # Import cv2 at the top level

logger = logging.getLogger(__name__)

# Constants for camera IDs
EXTERNAL_CAMERA = 0
INTERNAL_CAMERA = 2

class DeliveryFlow:
    """Handles the entire package delivery workflow using refactored services."""
    def __init__(self, **services):
        """Initializes the flow with all its required service dependencies."""
        self.aws = services.get("aws_client")
        self.gpio = services.get("gpio_service")
        self.tts = services.get("tts_service")
        self.ocr = services.get("ocr_processing") # The new, clean OCR service
        self.servo = services.get("servo_service")
        self.face_proc = services.get("face_processor")
        self.interaction_manager = services.get("interaction_manager")
        logger.info("Delivery Flow handler initialized.")

    def start_delivery_flow(self):
        """Main entry point for the delivery interaction flow."""
        logger.info("Starting delivery flow...")
        self.gpio.set_external_red_led(True)
        self.gpio.set_external_green_led(False)

        try:
            # The retry logic is now handled inside _scan_and_validate_external_package
            validated_code = self._scan_and_validate_external_package()
            if validated_code:
                logger.info(f"Valid package code '{validated_code}' found. Proceeding with delivery.")
                self._handle_compartment_door("Package accepted. Please place it inside the compartment, with the label facing up.")
                is_same_package = self._scan_internal_package(validated_code)
                
                if is_same_package:
                    self._finalize_delivery()
                else:
                    logger.info("Package rejected due to mismatch.")
                    self._handle_compartment_door("Opening the compartment door for you to remove the package.")
            else:
                self.tts.speak_async("Ok. Have a nice day!")

        except Exception as e:
            logger.error("An unexpected error occurred during the delivery flow.", exc_info=True)
            self.tts.speak("An unexpected error occurred. Please try again.")

        finally:
            logger.info("Ensuring all hardware is in a safe final state.")
            self.gpio.set_internal_led(False)
            self.gpio.set_external_green_led(False)
            self.gpio.set_external_red_led(True)

    def _scan_and_validate_external_package(self) -> str | None:
        """
        Scans for a package, validates it with AWS, and handles user feedback.
        Retries up to 3 times if validation fails.
        """
        self.gpio.set_camera_led(True)

        # Announce the initial action to the user without blocking the scan
        self.tts.speak_async("Please show the delivery code of the package to the camera.")

        aws_checker_callback = lambda code: self.aws.request_package_info("tracking_number", code)
        on_timeout = lambda: self.tts.speak_async("Move it closer to the camera and move it gently to help with scanning.")

        scan_timeout = 10.0 # Timeout for each scan attempt (Accounts for the tts speaking time)
        max_scan_attempts = 3

        logger.info(f"External package scan attempt")

        result = self.ocr.find_validated_code(
            camera_id=EXTERNAL_CAMERA,
            fast_mode=True,
            code_verification_callback=aws_checker_callback,
            timeout_sec=scan_timeout,
            retries=max_scan_attempts,
            on_timeout=on_timeout
        )

        # If successful, announce and return the code immediately
        if result["status"] == "success":
            self.gpio.set_camera_led(False)
            return result["code"]

        # If the AWS check resulted in a unknown package
        elif result["status"] == "not_accepted":
            logger.warning(f"External package scan failed. Response: {result['response']}")
            if self.interaction_manager.ask_yes_no("This package is not registered for delivery. Would you like to try scanning another package?", True):
                return self._scan_and_validate_external_package()
                
        # If timeout, ask to try again
        else:
            if self.interaction_manager.ask_yes_no("I still couldn't read the package code. Would you like to try again?"):
                logger.info("User chose to retry the external package scan.")
                return self._scan_and_validate_external_package()
            else:
                logger.info("User chose not to retry the external package scan.")

        # This part is reached only if all attempts fail
        self.gpio.set_camera_led(False)
        return None

    def _scan_internal_package(self, original_valid_codes: str) -> bool:
        """
        Scans the package inside the compartment using the same robust completer logic.
        Instead of an AWS check, it validates if the found code matches the original external code.
        Returns True if a matching code is found, False otherwise.
        """
        self.tts.speak_async("Verifying the package. Please wait a moment.")
        logger.info(f"Performing internal package scan, looking for: {original_valid_codes}")
        self.gpio.set_internal_led(True)

        # This simple lambda acts as our "validator". It replaces the AWS check.
        local_checker_callback = lambda code_to_check: {
            'package_same': True if code_to_check in original_valid_codes else False
        }
        on_timeout = lambda: self._handle_compartment_door("I couldn't verify the package code inside. Please ensure the code is visible and we will try again.")

        scan_timeout = 5.0  # Timeout for each scan attempt
        max_scan_attempts = 3

        logger.info(f"Internal package scan attempt")

        # We reuse the exact same robust function, just with a different callback.
        result = self.ocr.find_validated_code(
            camera_id=INTERNAL_CAMERA,
            fast_mode=False,  # Internal scans can be slower, so we disable fast mode
            code_verification_callback=local_checker_callback,  # Pass our local validator
            timeout_sec=scan_timeout,
            retries=max_scan_attempts,
            on_timeout=on_timeout
        )

        if result["status"] == "success":
            logger.info("Internal package verification successful. A matching code was found.")
            self.gpio.set_internal_led(False)
            return True

        # If not successful, ask to try again
        logger.error(f"Internal scan failed after all attempts. No match found for {original_valid_codes}.")
        if self.interaction_manager.ask_yes_no("I still couldn't verify the package code inside. Would you like to try again?"):
            logger.info("User chose to retry the internal package scan.")
            self._handle_compartment_door("Opening the compartment door for you to move the package.")
            return self._scan_internal_package(original_valid_codes)
        else:
            logger.info("User chose not to retry the internal package scan.")

        self.gpio.set_internal_led(False)
        return False

    def _handle_compartment_door(self, tts_text: str):
        """Opens the compartment and instructs the user."""
        self.tts.speak_async(tts_text, override=True)
        self.gpio.set_external_red_led(False)
        self.gpio.set_external_green_led(True)
        self.gpio.set_external_lock(True)
        time.sleep(14)
        self.gpio.set_external_lock(False)
        self.gpio.set_external_green_led(False)
        self.gpio.set_external_red_led(True)

    def _finalize_delivery(self):
        """Handles the successful delivery confirmation and secures the package."""
        self.tts.speak_async("Package validated. Thank you for your delivery.", override=True)
        self.aws.submit_log(
            event_type="package_detected", 
            summary="Package delivered", 
            details={}
        )
        logger.info("Finalizing delivery...")

        self.gpio.set_internal_led(True)
        self.gpio.set_external_green_led(False)
        self.gpio.set_external_red_led(True)

        video_filename = f"delivery_capture_{time.strftime('%Y%m%d_%H%M%S')}.mp4"
        video_filepath = os.path.join("data", "captures", video_filename)
        os.makedirs(os.path.dirname(video_filepath), exist_ok=True)

        try:
            self.face_proc.start_background_recording(INTERNAL_CAMERA, video_filepath) # Start background recording
            time.sleep(1)
            self.servo.openHatch() # Open the hatch
            time.sleep(5)
            self.servo.closeHatch() # Close the hatch
            
        except Exception as e:
            logger.error("An error occurred during the finalization sequence.", exc_info=True)
        finally:
            self.face_proc.stop_background_recording()
            self.gpio.set_internal_led(False)

        logger.info(f"Delivery finalized and package secured. Capture saved to {video_filepath}")
